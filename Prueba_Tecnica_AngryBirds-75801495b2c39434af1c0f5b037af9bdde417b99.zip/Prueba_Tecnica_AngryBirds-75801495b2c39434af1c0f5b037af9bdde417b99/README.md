# Prueba_Tecnica_AngryBirds
Partiendo por un prototipo basico del famoso juego AngryBirds se agregarán funcionalidades extras segun requerimientos. 
